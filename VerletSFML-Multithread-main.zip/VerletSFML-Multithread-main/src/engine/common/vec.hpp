#pragma once
#include <SFML/System/Vector2.hpp>

using Vec2  = sf::Vector2f;
using IVec2 = sf::Vector2i;


